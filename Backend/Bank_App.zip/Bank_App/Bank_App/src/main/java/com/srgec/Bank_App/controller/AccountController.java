package com.srgec.Bank_App.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.srgec.Bank_App.dto.DepositRequest;
import com.srgec.Bank_App.dto.WithdrawRequest;
import com.srgec.Bank_App.model.Account;
import com.srgec.Bank_App.service.AccountService;

@RestController
@RequestMapping("/accounts")
@CrossOrigin(origins = "http://localhost:5173")
public class AccountController {

    @Autowired
    private AccountService accountService;

    // Create Account
    @PostMapping("/create")
    public ResponseEntity<Account> createAccount(@RequestBody Account account) {

        Account savedAccount = accountService.createAccount(account);

        return ResponseEntity.ok(savedAccount);
    }

    // Get All Accounts
    @GetMapping("/all")
    public ResponseEntity<List<Account>> getAllAccounts() {

        return ResponseEntity.ok(accountService.getAllAccounts());
    }

    // Get Account by Account Number
    @GetMapping("/{accountNumber}")
    public ResponseEntity<Account> getAccount(@PathVariable String accountNumber) {

        Account account = accountService.getAccount(accountNumber);

        return ResponseEntity.ok(account);
    }

    // Deposit
    @PutMapping("/deposit")
    public ResponseEntity<Account> deposit(@RequestBody DepositRequest request) {

        Account account = accountService.deposit(
                request.getAccountNumber(),
                request.getAmount());

        return ResponseEntity.ok(account);
    }

    // Withdraw
    @PutMapping("/withdraw")
    public ResponseEntity<Account> withdraw(@RequestBody WithdrawRequest request) {

        Account account = accountService.withdraw(
                request.getAccountNumber(),
                request.getAmount());

        return ResponseEntity.ok(account);
    }

    // Delete Account
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteAccount(@PathVariable Integer id) {

        accountService.deleteAccount(id);

        return ResponseEntity.ok("Account Deleted Successfully");
    }
}