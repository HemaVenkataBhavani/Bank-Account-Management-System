package com.srgec.Bank_App.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.srgec.Bank_App.model.Transaction;
import com.srgec.Bank_App.service.TransactionService;

@RestController
@RequestMapping("/transactions")
@CrossOrigin("*")
public class TransactionController {

    @Autowired
    private TransactionService transactionService;

    @PostMapping
    public Transaction addTransaction(@RequestBody Transaction transaction) {
        return transactionService.saveTransaction(transaction);
    }

    @GetMapping
    public List<Transaction> getAllTransactions() {
        return transactionService.getAllTransactions();
    }

    @GetMapping("/{id}")
    public Transaction getTransactionById(@PathVariable Integer id) {
        return transactionService.getTransactionById(id);
    }

    @GetMapping("/account/{accountId}")
    public List<Transaction> getTransactionsByAccountId(
            @PathVariable Integer accountId) {
        return transactionService.getTransactionsByAccountId(accountId);
    }

    @DeleteMapping("/{id}")
    public String deleteTransaction(@PathVariable Integer id) {
        transactionService.deleteTransaction(id);
        return "Transaction Deleted Successfully";
    }
}