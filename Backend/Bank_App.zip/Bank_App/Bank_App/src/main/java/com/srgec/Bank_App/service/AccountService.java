package com.srgec.Bank_App.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.srgec.Bank_App.model.Account;
import com.srgec.Bank_App.repository.AccountRepository;

@Service
public class AccountService {

    @Autowired
    private AccountRepository accountRepository;

    // Create Account
    public Account createAccount(Account account) {
        return accountRepository.save(account);
    }

    // Get All Accounts
    public List<Account> getAllAccounts() {
        return accountRepository.findAll();
    }

    // Get Account by Account Number
    public Account getAccount(String accountNumber) {

        Account account = accountRepository.findByAccountNumber(accountNumber);

        if (account == null) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "Account not found");
        }

        return account;
    }

    // Deposit
    public Account deposit(String accountNumber, Double amount) {

        Account account = accountRepository.findByAccountNumber(accountNumber);

        if (account == null) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "Account not found");
        }

        account.setBalance(account.getBalance() + amount);

        return accountRepository.save(account);
    }

    // Withdraw
    public Account withdraw(String accountNumber, Double amount) {

        Account account = accountRepository.findByAccountNumber(accountNumber);

        if (account == null) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "Account not found");
        }

        if (account.getBalance() < amount) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Insufficient Balance");
        }

        account.setBalance(account.getBalance() - amount);

        return accountRepository.save(account);
    }

    // Delete Account
    public void deleteAccount(Integer accountId) {

        if (!accountRepository.existsById(accountId)) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "Account not found");
        }

        accountRepository.deleteById(accountId);
    }
}