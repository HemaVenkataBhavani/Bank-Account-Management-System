package com.srgec.Bank_App.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.srgec.Bank_App.model.Transaction;
import com.srgec.Bank_App.repository.TransactionRepository;

@Service
public class TransactionService {

    @Autowired
    private TransactionRepository transactionRepository;

    public Transaction saveTransaction(Transaction transaction) {
        return transactionRepository.save(transaction);
    }

    public List<Transaction> getAllTransactions() {
        return transactionRepository.findAll();
    }

    public Transaction getTransactionById(Integer id) {
        return transactionRepository.findById(id).orElse(null);
    }

    public List<Transaction> getTransactionsByAccountId(Integer accountId) {
        return transactionRepository.findByAccountId(accountId);
    }

    public void deleteTransaction(Integer id) {
        transactionRepository.deleteById(id);
    }
}